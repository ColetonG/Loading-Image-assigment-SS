package com.example.loadimageproject;


import androidx.appcompat.app.AppCompatActivity;


import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Random;

public class MainActivity extends AppCompatActivity {

    ArrayList<String> choices;

    {
        choices = new ArrayList<>();
    }

    TextView text;
    ImageView image;
    String selected;

    Button loadImage;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        /*Setting text and image to respected items */
        text = findViewById(R.id.textView);
        image = findViewById(R.id.imageView);
        loadImage = findViewById(R.id.laodImage);



        /* Population choices */
        choices.add("Purse");
        choices.add("Book-bag");
        choices.add("Scarf");
        choices.add("Hat");
        choices.add("Pants");
        choices.add("Shirt");
        choices.add("Shoes");

        Random rand = new Random();
        int rand_num = rand.nextInt(7);

        loadImage.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View v){
                Intent i = new Intent();
                i.setType("image/*");
                i.setAction(Intent.ACTION_GET_CONTENT);Random rand = new Random();
                int rand_num = rand.nextInt(7);
                selected = choices.get(rand_num);

                startActivityForResult(Intent.createChooser(i, "Choose Image"), 200);

                selected = choices.get(rand_num);
                text.setText(selected);
            }

        });


    }

    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == RESULT_OK) {

            // compare the resultCode with the
            // SELECT_PICTURE constant
            if (requestCode == 200) {
                // Get the url of the image from data
                Uri selectedImageUri = data.getData();
                // update the preview image in the layout
                if (null != selectedImageUri) {
                    image.setImageURI(selectedImageUri);
                }
            }
        }
    }
}